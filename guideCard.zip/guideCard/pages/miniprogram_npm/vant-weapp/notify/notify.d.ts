declare type NotifyOptions = {
    selector?: string;
    duration?: number;
    context?: any;
};
export default function Notify(options?: NotifyOptions): void;
export {};
