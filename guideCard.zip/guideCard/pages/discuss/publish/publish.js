const app = getApp()

Page({
    data: {
		// 17853531111
		// 测试数据库
    },
    formSubmit: function(e) {
        console.log(e.detail.value);
        if (e.detail.value.phone.length != 11) {
            wx.showToast({
                title: '手机号格式不正确!',
				image:'../../images/wrong2.png',
                duration: 1500
            })
            setTimeout(function() {
                wx.hideToast()
            }, 2000)
        } else if (e.detail.value.title.length == 0) {
            wx.showToast({
                title: '标题不能为空!',
				image: '../../images/wrong2.png',
                duration: 1500
            })
            setTimeout(function() {
                wx.hideToast()
            }, 2000)
		} else if (e.detail.value.content.length == 0) {
			wx.showToast({
				title: '内容不能为空!',
				image: '../../images/wrong2.png',
				duration: 1500
			})
			setTimeout(function () {
				wx.hideToast()
			}, 2000)}
			else {
            wx.request({
                url: 'https://www.daoyouyidiantong.cn/publish.php',
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                data: {
                    phone: e.detail.value.phone,
                    title: e.detail.value.title,
                    content: e.detail.value.content
                },
                success: function(res) {
                    console.log(res.data);
                    if (res.data.status == 0) {
                        wx.showToast({
                            title: '提交失败！！！',
                            icon: 'loading',
                            duration: 1500
                        })
                    } else {
                        wx.showToast({
                            title: '提交成功！！！', //这里打印出登录成功
                            icon: 'success',
                        })
						wx.switchTab({
							url: '../discuss',   //注意switchTab只能跳转到带有tab的页面，不能跳转到不带tab的页面
						})
                    }
                }
            })
        }
    }
})