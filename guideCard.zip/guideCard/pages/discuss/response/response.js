Page({
	data: {
		// 对象 
		detail: {},
	},

	onLoad: function (options) {
		wx.showToast({
			title: '加载中,请稍候...',
			icon: "loading"
		})
		var that = this
		// 字符串转json 
		var info = JSON.parse(options.Mesgs);
		//console.log(info)
		that.setData({
			// 把从index页面获取到的属性值赋给详情页的detail，供详情页使用 
			detail: info
		})
	}
})