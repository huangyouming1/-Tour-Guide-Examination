var app = getApp();
Page({

    data: {

    },
    /** 
     * 生命周期函数--监听页面加载 
     */
    onLoad: function(options) {
        wx.showToast({
            title: '加载中...',
            icon: "loading"
        })
        var that = this
        wx.request({
            url: 'https://www.daoyouyidiantong.cn/discuss.php',
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                //console.log(res.data),
                    that.setData({
                        list: res.data,
                        //res代表success函数的事件对，data是固定的，list是数组 
                    })
            }
        })
    },
    onPostTap: function(event) {
        var that = this
        var discussId = event.currentTarget.dataset.index;
        app.requestDetailid = discussId;
        var mesg = that.data.list[discussId];
        mesg = JSON.stringify(mesg);
        wx.navigateTo({
            //将本页面的id传到需要跳转的页面 
            url: "../discuss/response/response?Mesgs=" + mesg,
        })
    },
	searchTap: function (event) {
		var that = this
		var discussId = event.currentTarget.dataset.index;
		app.requestDetailid = discussId;
		var mesg = that.data.re[discussId];
		mesg = JSON.stringify(mesg);
		wx.navigateTo({
			//将本页面的id传到需要跳转的页面 
			url: "../discuss/response/response?Mesgs=" + mesg,
		})
	},
    onPullDownRefresh: function() {
        // 显示顶部刷新图标
        wx.showNavigationBarLoading();
        var that = this;
        wx.request({
            url: 'https://www.daoyouyidiantong.cn/discuss.php',
            method: "GET",
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                that.setData({
                    list: res.data,
                    //res代表success函数的事件对，data是固定的，list是数组 
                })
                // 隐藏导航栏加载框
                wx.hideNavigationBarLoading();
                // 停止下拉动作
                wx.stopPullDownRefresh();
            }
        })
    },
	formSubmit: function (event) {
		var that = this;
		var formData = event.detail;
		//console.log(formData)
		//显示搜索中的提示
		wx.showLoading({
			title: '搜索中',
			icon: 'loading'
		})
		//向搜索后端服务器发起请求
		wx.request({
			//URL
			url: 'https://www.daoyouyidiantong.cn/search.php?keyword=' + formData,
			//发送的数据
			data: formData,
			//请求的数据时JSON格式
			header: {
				'Content-Type': 'application/json'
			},
			//请求成功
			success: function (res) {
				//控制台打印（开发调试用）
				console.log(res.data)
				//把所有结果存进一个名为re的数组
				that.setData({
					re: res.data,
				})
				//搜索成功后，隐藏搜索中的提示
				wx.hideLoading();
			}
		})
	}
})