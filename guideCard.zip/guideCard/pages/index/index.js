var app = getApp();
Page({

    data: {
        img: [{
                imgUrl: '../../images/daoyou1.png',
				link: '/pages/scorll/scorll'
            },
            {
                imgUrl: '../../images/daoyou2.jpg',
                link: '/pages/scorll/scorll'
            },
            {
                imgUrl: '../../images/daoyou3.jpg',
				link: '/pages/scorll/scorll'
            }
        ],
        circular: true,
        indicatorDots: true,
        autoplay: true,
        interval: 5000,
        duration: 1000
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var that = this
        wx.showToast({
            title: '加载中...',
            icon: "loading"
        })
        wx.request({
            url: 'https://www.daoyouyidiantong.cn/videoList.php',
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                //console.log(res.data),
                that.setData({
                    list: res.data,
                    //res代表success函数的事件对，data是固定的，list是数组
                })
            }
        })
 
    },
    onPostTap: function(event) {
		//console.log(event)
        var that = this
        var videoId = event.currentTarget.dataset.index;
        app.requestDetailid = videoId;
        var mesg = that.data.list[videoId];
        mesg = JSON.stringify(mesg);
        wx.navigateTo({
            //将本页面的id传到需要跳转的页面
            url: "../detail/detail?Mesgs=" + mesg,
        })
    },
    swipclick: function(event) {
        wx.navigateTo({
            url: event.currentTarget.dataset.link // 页面跳转地址
        })
    },
    click1: function() {
        wx.navigateTo({
            url: '../python/python',
        })
    },
    click2: function() {
        wx.navigateTo({
            url: '../testing/testing',
        })
    },
    click3: function() {
        wx.navigateTo({
            url: '../collection/collection',
        })
    },
    click4: function() {
        wx.navigateTo({
            url: '../wrong/wrong',
        })
    },
    onPullDownRefresh: function() {
        // 显示顶部刷新图标
        wx.showNavigationBarLoading();
        var that = this;

        wx.request({
            url: 'https://www.daoyouyidiantong.cn/videoList.php',
            method: "GET",
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                that.setData({
                    list: res.data,
                    //res代表success函数的事件对，data是固定的，list是数组
                })
                // 隐藏导航栏加载框
                wx.hideNavigationBarLoading();
                // 停止下拉动作
                wx.stopPullDownRefresh();
            }
        })
    }
})