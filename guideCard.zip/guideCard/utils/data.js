const python = [{
        id: 1,
        type: '判断',
        q: '1.党的十八届四中全会提出，坚持依法治国首先要坚持依宪治国，坚持依法执政首先要坚持依宪执政。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'A',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 2,
        type: '判断',
        q: '2.依法治国、依法执政、依法行政是一个内在统一的有机整体，其中依法治国处于关键的支配性地位。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 3,
        type: '判断',
        q: '3.全面推进依法治国，加快建设法治中国，基本的立足点是坚持人民主体地位。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 4,
        type: '判断',
        q: '4.深化行政执法体制改革要求健全行政执法和刑事司法衔接机制，支持以罚代刑。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 5,
        type: '判断',
        q: '5.加强对政府外部权力的制约，这是强化对行政权力制约的重点。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 6,
        type: '判断',
        q: '6.优化司法职权配置要求改革法院案件受理制度，变立案登记制为立案审查制。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 7,
        type: '判断',
        q: '7.推进严格司法要求推进以检察为中心的诉讼制度改革。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 8,
        type: '判断',
        q: '8.保障人民群众参与司法要求把完善人民陪审员制度作为深入推进司法民主的基本立足点。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'A',
        isStore: false,
        isAnswer: 0
    },
    {
        id: 9,
        type: '判断',
        q: '9.依法行政是依法治国的关键，提高党的依法执政能力、加强和改善党的领导是改革和完善中国共产党的领导方式和执政方式的重要途径。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        q: '已知x是一个列表，那么x ',
        id: 10,
        type: '判断',
        q: '10.提高党员干部法治思维就是指党员干部要带头遵守法律、运用逻辑推理解决问题、依法进行重大决策。',
        options: [{
            label: 'A',
            text: '正确'
        }, {
            label: 'B',
            text: '错误'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
    {
        q: '中国共产党第一次专题研究依法治国问题的中央全会是（）',
        a: 'D',
        id: 11,
        type: '单选',
        options: [{
            label: 'A',
            text: '十七届三中全会'
        }, {
            label: 'B',
            text: '十七届四中全会'
        }, {
            label: 'C',
            text: '十八届三中全会'
        }, {
            label: 'D',
            text: '十八届四中全会'
        }],
        isStore: false,
        isAnswer: 0
    },
    {
        q: '（）是社会主义民主政治的本质要求和基本目标。 ',
        a: 'B',
        id: 12,
        type: '单选',
        options: [{
            label: 'A',
            text: '党的领导  '
        }, {
            label: 'B',
            text: '人民当家作主  '
        }, {
            label: 'C',
            text: '依法治国  '
        }, {
            label: 'D',
            text: '维护社会公平正义'
        }],
        isStore: false,
        isAnswer: 0
    },
    {
        id: 13,
        type: '单选',
        q: '在党的领导、人民当家作主、依法治国的有机统一体中，三者关系表述错误的是（）。',
        options: [{
            label: 'A',
            text: '党的领导是核心，是人民当家作主和依法治国的根本政治保证'
        }, {
            label: 'B',
            text: '人民当家作主是由依法治国的本质属性决定的'
        }, {
            label: 'C',
            text: '人民当家作主是社会主义民主政治的本质要求和基本目标  '
        }, {
            label: 'D',
            text: '依法治国是党领导人民治理国家的基本方略'
        }],
        a: 'B',
        isStore: false,
        isAnswer: 0
    },
        {
        q: '全面推进依法治国的总目标是（）。 ',
        a: 'C',
        id: 14,
        type: '单选',
        options: [{
            label: 'A',
            text: '建设中国特色社会主义法制体系  '
        }, {
            label: 'B',
            text: '建设社会主义法治国家  '
        }, {
            label: 'C',
            text: '建设中国特色社会主义法制体系，建设社会主义法治国家  '
        }, {
            label: 'D',
            text: '建设中国特色的社会主义法治国家'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '（）是依法治国的实践基础。 ',
        a: 'C',
        id: 15,
        type: '单选',
        options: [{
            label: 'A',
            text: '坚持中国共产党的领导        '
        }, {
            label: 'B',
            text: '坚持人民主体地位  '
        }, {
            label: 'C',
            text: '坚持从中国实际出发           '
        }, {
            label: 'D',
            text: '坚持依法治国和以德治国相结合'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '（）既是中国特色社会主义最本质的特征，也是社会主义法治最根本的保证。 ',
        a: 'A',
        id: 16,
        type: '单选',
        options: [{
            label: 'A',
            text: '党的领导  '
        }, {
            label: 'B',
            text: '人民当家作主  '
        }, {
            label: 'C',
            text: '坚持依法治国、依法执政、依法行政共同推进  '
        }, {
            label: 'D',
            text: '坚持法治国家、法治政府、法治社会一体建设'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '中国特色社会主义法律体系已经形成是在（）上宣布的。 ',
        a: 'B',
        id: 17,
        type: '单选',
        options: [{
            label: 'A',
            text: '十一届全国人大三次会议        '
        }, {
            label: 'B',
            text: '十一届全国人大四次会议  '
        }, {
            label: 'C',
            text: '十二届全国人大三次会议        '
        }, {
            label: 'D',
            text: '十二届全国人大四次会议'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '建立严密的法治监督体系，最关键的就是（）。 ',
        a: 'C',
        id: 18,
        type: '单选',
        options: [{
            label: 'A',
            text: '党内监督和人大监督     '
        }, {
            label: 'B',
            text: '人大监督和行政监督  '
        }, {
            label: 'C',
            text: '行政监督和司法监督     '
        }, {
            label: 'D',
            text: '人大监督和审计监督'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '推进党内法规同国家法律的衔接和协调，首先要坚持以（）为基本遵循。 ',
        a: 'C',
        id: 19,
        type: '单选',
        options: [{
            label: 'A',
            text: '党章        '
        }, {
            label: 'B',
            text: '宪法        '
        }, {
            label: 'C',
            text: '党章和宪法        '
        }, {
            label: 'D',
            text: '宪法和法律'
        }],
        isStore: false,
        isAnswer: 0
    },
        {
        q: '下列关于完善立体法制的工作任务说法错误的是（） ',
        a: 'B',
        id: 20,
        type: '单选',
        options: [{
            label: 'A',
            text: '加强党对立法工作的领导        '
        }, {
            label: 'B',
            text: '健全党主导的立法体制机制  '
        }, {
            label: 'C',
            text: '加强和改进政府立法制度建设    '
        }, {
            label: 'D',
            text: '明确立法权力边界'
        }],
        isStore: false,
        isAnswer: 0
    }
]

module.exports = {
    data: python
}